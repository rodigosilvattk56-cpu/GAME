package com.rdgame.optimizer;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(7, 11, 19);
    private final int panel = Color.rgb(17, 27, 43);
    private final int neon = Color.rgb(65, 255, 151);
    private final int blue = Color.rgb(48, 170, 255);
    private TextView ramValue, storageValue, batteryValue, status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        refreshStats();
    }

    private GradientDrawable rounded(int color, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(28);
        if (strokeColor != 0) d.setStroke(2, strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = vertical();
        root.setPadding(22, 28, 22, 30);
        scroll.addView(root);

        TextView tag = text("ANDROID • MOTO G54 5G", 11, blue, true);
        root.addView(tag);

        TextView title = text("RD GAME", 34, Color.WHITE, true);
        title.setPadding(0, 4, 0, 0);
        root.addView(title);

        TextView subtitle = text("PAINEL DE OTIMIZAÇÃO GAMER", 12, neon, true);
        subtitle.setPadding(0, 0, 0, 20);
        root.addView(subtitle);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.VERTICAL);
        stats.setPadding(16, 14, 16, 14);
        stats.setBackground(rounded(panel, blue));
        root.addView(stats, params(-1, -2, 0, 0, 0, 18));

        ramValue = text("Memória RAM: lendo…", 15, Color.WHITE, true);
        storageValue = text("Armazenamento: lendo…", 15, Color.WHITE, true);
        batteryValue = text("Bateria: lendo…", 15, Color.WHITE, true);
        stats.addView(ramValue); stats.addView(storageValue); stats.addView(batteryValue);

        Button play = makeButton("▶  ABRIR FREE FIRE", neon);
        root.addView(play, params(-1, 58, 0, 0, 0, 10));
        play.setOnClickListener(v -> launchFreeFire());

        Button refresh = makeButton("↻  ATUALIZAR MONITORAMENTO", blue);
        root.addView(refresh, params(-1, 52, 0, 0, 0, 18));
        refresh.setOnClickListener(v -> refreshStats());

        root.addView(text("FERRAMENTAS", 13, neon, true), params(-1, -2, 0, 0, 0, 10));
        addTool(root, "Modo de bateria", "Abrir as opções de economia e uso da bateria", () ->
                openSettings(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        addTool(root, "Armazenamento", "Ver espaço livre e gerenciar arquivos", () ->
                openSettings(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)));
        addTool(root, "Tela e taxa de atualização", "Abrir as configurações de tela do Android", () ->
                openSettings(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        addTool(root, "Informações do aplicativo", "Acessar configurações do RD GAME", () -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            openSettings(i);
        });

        status = text("Dica: feche apps que não estiver usando e mantenha o Android atualizado.", 12, 0xFFB8C7D9, false);
        status.setPadding(4, 16, 4, 0);
        root.addView(status);

        TextView disclaimer = text("O RD GAME não altera arquivos do Free Fire, não força aumento de FPS e não limpa dados de outros aplicativos. Os ajustes são feitos pelo próprio Android.", 11, 0xFF8495AA, false);
        disclaimer.setPadding(4, 16, 4, 0);
        root.addView(disclaimer);

        setContentView(scroll);
    }

    private LinearLayout.LayoutParams params(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }

    private Button makeButton(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(bg);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(rounded(color, 0));
        return b;
    }

    private void addTool(LinearLayout root, String title, String detail, Runnable action) {
        LinearLayout card = vertical();
        card.setPadding(15, 12, 15, 12);
        card.setBackground(rounded(panel, 0));
        root.addView(card, params(-1, -2, 0, 0, 0, 9));
        card.addView(text(title, 15, Color.WHITE, true));
        TextView desc = text(detail, 11, 0xFF9FB0C5, false);
        desc.setPadding(0, 3, 0, 0);
        card.addView(desc);
        card.setOnClickListener(v -> action.run());
    }

    private void refreshStats() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        DecimalFormat df = new DecimalFormat("0.0");
        double totalRam = mi.totalMem / 1073741824.0;
        double availRam = mi.availMem / 1073741824.0;
        ramValue.setText("RAM disponível: " + df.format(availRam) + " GB / " + df.format(totalRam) + " GB");

        StatFs fs = new StatFs(getFilesDir().getAbsolutePath());
        double free = fs.getAvailableBytes() / 1073741824.0;
        double total = fs.getTotalBytes() / 1073741824.0;
        storageValue.setText("Armazenamento livre: " + df.format(free) + " GB / " + df.format(total) + " GB");

        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int pct = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
        batteryValue.setText("Bateria: " + (pct >= 0 ? pct + "%" : "indisponível"));
        status.setText("Monitoramento atualizado. Para melhor estabilidade, feche apps em segundo plano e evite jogar enquanto o celular estiver muito quente.");
    }

    private void launchFreeFire() {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if (i == null) i = getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
        if (i != null) startActivity(i);
        else status.setText("Free Fire não encontrado. Instale o jogo pela loja oficial e tente novamente.");
    }

    private void openSettings(Intent i) {
        try { startActivity(i); }
        catch (Exception e) {
            status.setText("Essa tela de configuração não está disponível nesta versão do Android.");
        }
    }
}
