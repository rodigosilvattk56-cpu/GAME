# RD GAME — projeto Android

Projeto inicial nativo para Android, com visual preto/verde/azul e foco no Moto G54 5G.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `RD_GAME_Android_Project`.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale Android SDK Platform 35 e Build Tools.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Recursos incluídos
- Painel com leitura de RAM disponível, armazenamento e bateria.
- Atalho para abrir Free Fire / Free Fire MAX, se instalado.
- Atalhos para configurações de bateria, armazenamento e tela.

## Limitações importantes
Android não permite que um app comum encerre processos de outros apps, limpe seus dados/cache privados ou altere a sensibilidade/FPS do Free Fire. O RD GAME não promete ganhos artificiais de desempenho.
